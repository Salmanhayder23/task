#include <windows.h>
#include <GL/glut.h>
#include <math.h>
#include <iostream>

using namespace std;
/* Initialize OpenGL Graphics */

int frameNumber = 0;
float _move = 0.0f;
float _move1 = 0.0f;
float _move2 = 280.0f;
float _move4 = 0.0f;
float _move5 = 280.0f;
float xr = 0, yr = 0;
float xr1 = 0, yr1 = 0;
GLfloat position = -190.0f;
GLfloat speed = 2.0f;
GLfloat position1 = 190.0f;
GLfloat speed1 = 2.0f;
void dis();
void display();


void initGL() {
	glClearColor(0.0f, 0.5f, 0.5f, 0.0f); // Blue and opaque
	glLoadIdentity(); //Reset the drawing perspective
	gluOrtho2D(-100,200,-280,200);
}

void Cloud1()//C1
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(_move,0.0f, 0.0f);
    //Circle 1
    glBegin(GL_POLYGON);// Draw a Red 1x1 Square centered at origin
	for(int i=0;i<200;i++)
        {
            glColor3ub(192,192,192);
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=10.0;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y+150.0f );
        }
	glEnd();
	//Circle 2
	glBegin(GL_POLYGON);// Draw a Red 1x1 Square centered at origin
	for(int i=0;i<200;i++)
        {
            glColor3ub(160,160,160);
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=10.0;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x+10,y+155.0f );
        }
	glEnd();
	//Circle 3
	glBegin(GL_POLYGON);// Draw a Red 1x1 Square centered at origin
	for(int i=0;i<200;i++)
        {
            glColor3ub(192,192,192);
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=10.0;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x+15,y+145.0f );
        }
	glEnd();
	glPopMatrix();

	glutSwapBuffers();

}
//Cloud 2
void Cloud2()//C2
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(_move,0.0f, 0.0f);
    //Circle 1
    glBegin(GL_POLYGON);// Draw a Red 1x1 Square centered at origin
	for(int i=0;i<200;i++)
        {
            glColor3ub(160,160,160);
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=10.0;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x-70,y+185.0f );
        }
	glEnd();
	//Circle 2
	glBegin(GL_POLYGON);// Draw a Red 1x1 Square centered at origin
	for(int i=0;i<200;i++)
        {
            glColor3ub(192,192,192);
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=15.0;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x-61,y+175.0f );
        }
	glEnd();
	//Circle 3
	glBegin(GL_POLYGON);// Draw a Red 1x1 Square centered at origin
	for(int i=0;i<200;i++)
        {
            glColor3ub(192,192,192);
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=10.0;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x-80,y+177.0f );
        }
	glEnd();
	glPopMatrix();

	glutSwapBuffers();

}
//Cloud 3
void Cloud3()//C3
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(_move,0.0f, 0.0f);
    //Circle 1
    glBegin(GL_POLYGON);// Draw a Red 1x1 Square centered at origin
	for(int i=0;i<200;i++)
        {
            glColor3ub(160,160,160);
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=10.0;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x-130,y+120.0f );
        }
	glEnd();
	//Circle 2
	glBegin(GL_POLYGON);// Draw a Red 1x1 Square centered at origin
	for(int i=0;i<200;i++)
        {
            glColor3ub(160,160,160);
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=10.0;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x-115,y+130.0f );
        }
	glEnd();
	//Circle 3
	glBegin(GL_POLYGON);// Draw a Red 1x1 Square centered at origin
	for(int i=0;i<200;i++)
        {
            glColor3ub(128,128,128);
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=10.0;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x-100,y+120.0f );
        }
	glEnd();

	//Circle 4
	glBegin(GL_POLYGON);// Draw a Red 1x1 Square centered at origin
	for(int i=0;i<200;i++)
        {
            glColor3ub(160,160,160);
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=14.0;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x-115,y+108.0f );
        }
	glEnd();
	glPopMatrix();

	glutSwapBuffers();

}
//Cloud 4
void Cloud4()//C4
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(_move,0.0f, 0.0f);
    //Circle 1
    glBegin(GL_POLYGON);// Draw a Red 1x1 Square centered at origin
	for(int i=0;i<200;i++)
        {
            glColor3ub(160,160,160);
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=15.0;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x-200,y+140.0f );
        }
	glEnd();
	//Circle 2
	glBegin(GL_POLYGON);// Draw a Red 1x1 Square centered at origin
	for(int i=0;i<200;i++)
        {
            glColor3ub(160,160,160);
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=10.0;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x-215,y+125.0f );
        }
	glEnd();
	//Circle 3
	glBegin(GL_POLYGON);// Draw a Red 1x1 Square centered at origin
	for(int i=0;i<200;i++)
        {
            glColor3ub(128,128,128);
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=10.0;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x-212,y+110.0f );
        }
	glEnd();

	//Circle 4
	glBegin(GL_POLYGON);// Draw a Red 1x1 Square centered at origin
	for(int i=0;i<200;i++)
        {
            glColor3ub(160,160,160);
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=14.0;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x-195,y+100.0f );
        }
	glEnd();
	//Circle 5
	glBegin(GL_POLYGON);// Draw a Red 1x1 Square centered at origin
	for(int i=0;i<200;i++)
        {
            glColor3ub(128,128,128);
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=14.0;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x-180,y+120.0f );
        }
	glEnd();
	//Circle 6
	glBegin(GL_POLYGON);// Draw a Red 1x1 Square centered at origin
	for(int i=0;i<200;i++)
        {
            glColor3ub(160,160,160);
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=15.0;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x-200,y+125.0f );
        }
	glEnd();
	glPopMatrix();

	glutSwapBuffers();

}
//U1
void UpdateCloud(int value) {

    _move += 1.0;
    if(_move > 450.0)
    {
        _move = -120.0;
    }
    glutPostRedisplay(); //Notify GLUT that the display has changed

    glutTimerFunc(20, UpdateCloud, 0); //Notify GLUT to call update again in 25 milliseconds
}

//Ship 1
void Ship1()//SP1
{

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(_move1,-10.0f, 0.0f);
    glBegin(GL_POLYGON);//layer_1
    glColor3ub(0,51,102);//color_
    glVertex2f(-58.0f, -230.0f);
    glVertex2f(-23.0f, -230.0f);
    glVertex2f(-30.0f, -240.0f);
    glVertex2f(-55.0f, -240.0f);
    glEnd();

    glBegin(GL_POLYGON);//layer_3
    glColor3ub(0,25,51);//color_
    glVertex2f(-52.0f, -215.0f);
    glVertex2f(-35.0f, -215.0f);
    glVertex2f(-35.0f, -230.0f);
    glVertex2f(-52.0f, -230.0f);
    glEnd();
    glBegin(GL_POLYGON);//layer_2
    glColor3ub(192,192,192);//color_
    glVertex2f(-41.0f, -228.0f);
    glVertex2f(-21.0f, -228.0f);
    glVertex2f(-23.0f, -230.0f);
    glVertex2f(-42.5f, -230.0f);
    glEnd();
    glBegin(GL_POLYGON);//Layer_4
    glColor3ub(192,192,192);//color_
    glVertex2f(-50.0f, -205.0f);
    glVertex2f(-37.0f, -205.0f);
    glVertex2f(-37.0f, -215.0f);
    glVertex2f(-50.0f, -215.0f);
    glEnd();
    glBegin(GL_POLYGON);//layer_5
    glColor3ub(0,25,51);//color_
    glVertex2f(-38.0f, -195.0f);
    glVertex2f(-42.0f, -195.0f);
    glVertex2f(-42.0f, -205.0f);
    glVertex2f(-38.0f, -205.0f);
    glEnd();
    glBegin(GL_POLYGON);//layer_3_window
    glColor3ub(0,102,204);//color_
    glVertex2f(-50.0f, -220.0f);
    glVertex2f(-40.0f, -220.0f);
    glVertex2f(-40.0f, -226.0f);
    glVertex2f(-50.0f, -226.0f);
    glEnd();
    glBegin(GL_POLYGON);//Layer_4_window_1
    glColor3ub(0,51,102);//color_
    glVertex2f(-48.0f, -208.0f);
    glVertex2f(-44.0f, -208.0f);
    glVertex2f(-44.0f, -212.0f);
    glVertex2f(-48.0f, -212.0f);
    glEnd();
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(6.0f, 0.0f, 0.0f);
    glBegin(GL_POLYGON);//Layer_4_window_2
    glColor3ub(0,51,102);//color_
    glVertex2f(-48.0f, -208.0f);
    glVertex2f(-44.0f, -208.0f);
    glVertex2f(-44.0f, -212.0f);
    glVertex2f(-48.0f, -212.0f);
    glEnd();
    glPopMatrix();

    glPopMatrix();

}
//Ship 2
void Ship2()//SP2
{

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(_move2,0.0f, 0.0f);
    glPushMatrix();
    glTranslatef(-50.0f,70.0f, 0.0f);
    glBegin(GL_POLYGON);//layer_1
    glColor3ub(153,0,0);//color_
    glVertex2f(-58.0f, -230.0f);
    glVertex2f(-23.0f, -230.0f);
    glVertex2f(-30.0f, -240.0f);
    glVertex2f(-55.0f, -240.0f);
    glEnd();

    glBegin(GL_POLYGON);//layer_3
    glColor3ub(0,25,51);//color_
    glVertex2f(-52.0f, -215.0f);
    glVertex2f(-35.0f, -215.0f);
    glVertex2f(-35.0f, -230.0f);
    glVertex2f(-52.0f, -230.0f);
    glEnd();

    glBegin(GL_POLYGON);//Layer_4
    glColor3ub(192,192,192);//color_
    glVertex2f(-50.0f, -205.0f);
    glVertex2f(-37.0f, -205.0f);
    glVertex2f(-37.0f, -215.0f);
    glVertex2f(-50.0f, -215.0f);
    glEnd();
    glBegin(GL_POLYGON);//layer_5
    glColor3ub(0,25,51);//color_
    glVertex2f(-38.0f, -195.0f);
    glVertex2f(-42.0f, -195.0f);
    glVertex2f(-42.0f, -205.0f);
    glVertex2f(-38.0f, -205.0f);
    glEnd();
    glBegin(GL_POLYGON);//layer_3_window
    glColor3ub(0,205,205);//color_
    glVertex2f(-50.0f, -220.0f);
    glVertex2f(-40.0f, -220.0f);
    glVertex2f(-40.0f, -226.0f);
    glVertex2f(-50.0f, -226.0f);
    glEnd();
    glBegin(GL_POLYGON);//Layer_4_window_1
    glColor3ub(153,0,0);//color_
    glVertex2f(-48.0f, -208.0f);
    glVertex2f(-44.0f, -208.0f);
    glVertex2f(-44.0f, -212.0f);
    glVertex2f(-48.0f, -212.0f);
    glEnd();
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(6.0f, 0.0f, 0.0f);
     glBegin(GL_POLYGON);//Layer_4_window_2
    glColor3ub(153,0,0);//color_
    glVertex2f(-48.0f, -208.0f);
    glVertex2f(-44.0f, -208.0f);
    glVertex2f(-44.0f, -212.0f);
    glVertex2f(-48.0f, -212.0f);
    glEnd();
    glPopMatrix();
    glPopMatrix();
    glPopMatrix();
}
//Speed Boat
void SpeedBoat()//SB
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(_move4,-10.0f, 0.0f);
    glBegin(GL_TRIANGLES);//window
    glColor3ub(0,255,255);//color_
    glVertex2f(-51.0f, -125.0f);
    glVertex2f(-45.0f, -117.0f);
    glVertex2f(-42.0f, -124.0f);
    glEnd();

    glBegin(GL_LINES);//window_stripe
    glColor3ub(0,0,0);//color_
    glVertex2f(-47.0f, -120.0f);
    glVertex2f(-46.0f, -125.0f);
    glEnd();

    glBegin(GL_POLYGON);//layer_1
    glColor3ub(220,220,220);//color_
    glVertex2f(-55.0f, -126.0f);

    glVertex2f(-40.0f, -120.0f);
    glVertex2f(-43.0f, -130.0f);
    glVertex2f(-55.0f, -130.0f);
    glEnd();

    glBegin(GL_LINES);//boat_stripe
    glColor3ub(153,0,0);//color_
    glVertex2f(-55.0f, -128.0f);
    glVertex2f(-42.0f, -128.0f);
    glEnd();

    glPointSize(2.0);
    glBegin(GL_POINTS);
    glColor3ub(51,255,255);
    glVertex2f(-56.0f, -128.0f);
    glEnd();
    glPointSize(2.0);
    glBegin(GL_POINTS);
    glColor3ub(51,255,255);
    glVertex2f(-57.0f, -127.0f);
    glEnd();
    glPointSize(2.0);
    glBegin(GL_POINTS);
    glColor3ub(51,255,255);
    glVertex2f(-58.0f, -126.0f);
    glEnd();
    glPointSize(2.0);
    glBegin(GL_POINTS);
    glColor3ub(51,255,255);
    glVertex2f(-59.0f, -127.0f);
    glEnd();
    glPointSize(2.0);
    glBegin(GL_POINTS);
    glColor3ub(51,255,255);
    glVertex2f(-60.0f, -128.0f);
    glEnd();

    glPushMatrix();
    glTranslatef(-1.0f,-2.0f, 0.0f);
    glPointSize(2.0);
    glBegin(GL_POINTS);
    glColor3ub(51,255,255);
    glVertex2f(-56.0f, -128.0f);
    glEnd();
    glPointSize(2.0);
    glBegin(GL_POINTS);
    glColor3ub(51,255,255);
    glVertex2f(-57.0f, -127.0f);
    glEnd();
    glPointSize(2.0);
    glBegin(GL_POINTS);
    glColor3ub(51,255,255);
    glVertex2f(-58.0f, -126.0f);
    glEnd();
    glPointSize(2.0);
    glBegin(GL_POINTS);
    glColor3ub(51,255,255);
    glVertex2f(-59.0f, -127.0f);
    glEnd();
    glPointSize(2.0);
    glBegin(GL_POINTS);
    glColor3ub(51,255,255);
    glVertex2f(-60.0f, -128.0f);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-2.0f,-3.0f, 0.0f);
    glPointSize(2.0);
    glBegin(GL_POINTS);
    glColor3ub(51,255,255);
    glVertex2f(-56.0f, -128.0f);
    glEnd();
    glPointSize(2.0);
    glBegin(GL_POINTS);
    glColor3ub(51,255,255);
    glVertex2f(-57.0f, -127.0f);
    glEnd();
    glPointSize(2.0);
    glBegin(GL_POINTS);
    glColor3ub(51,255,255);
    glVertex2f(-58.0f, -126.0f);
    glEnd();
    glPointSize(2.0);
    glBegin(GL_POINTS);
    glColor3ub(51,255,255);
    glVertex2f(-59.0f, -127.0f);
    glEnd();
    glPointSize(2.0);
    glBegin(GL_POINTS);
    glColor3ub(51,255,255);
    glVertex2f(-60.0f, -128.0f);
    glEnd();
    glPopMatrix();

    glPopMatrix();

}
//wave
void Wave()//WV
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(_move5,0.0f, 0.0f);
    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(-90.0f, -120.0f);
    glVertex2f(-75.0f, -120.0f);
    glEnd();

    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(-85.0f, -125.0f);
    glVertex2f(-70.0f, -125.0f);
    glEnd();

    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(-93.0f, -130.0f);
    glVertex2f(-82.0f, -130.0f);
    glEnd();

    glPushMatrix();
    glTranslatef(50.0f,-80.0f, 0.0f);

    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(-90.0f, -120.0f);
    glVertex2f(-75.0f, -120.0f);
    glEnd();

    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(-85.0f, -125.0f);
    glVertex2f(-70.0f, -125.0f);
    glEnd();

    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(-93.0f, -130.0f);
    glVertex2f(-82.0f, -130.0f);
    glEnd();
    glPopMatrix();


    glPushMatrix();
    glTranslatef(150.0f,-20.0f, 0.0f);

    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(-90.0f, -120.0f);
    glVertex2f(-75.0f, -120.0f);
    glEnd();

    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(-85.0f, -125.0f);
    glVertex2f(-70.0f, -125.0f);
    glEnd();

    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(-93.0f, -130.0f);
    glVertex2f(-82.0f, -130.0f);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(180.0f,-120.0f, 0.0f);

    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(-90.0f, -120.0f);
    glVertex2f(-75.0f, -120.0f);
    glEnd();

    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(-85.0f, -125.0f);
    glVertex2f(-70.0f, -125.0f);
    glEnd();

    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(-93.0f, -130.0f);
    glVertex2f(-82.0f, -130.0f);
    glEnd();
    glPopMatrix();

    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(20.0f, -160.0f);
    glVertex2f(15.0f, -160.0f);
    glEnd();

    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(25.0f, -165.0f);
    glVertex2f(17.0f, -165.0f);
    glEnd();

    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(15.0f, -168.0f);
    glVertex2f(10.0f, -168.0f);
    glEnd();

    glPushMatrix();
    glTranslatef(-110.0f,-100.0f, 0.0f);
    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(20.0f, -160.0f);
    glVertex2f(15.0f, -160.0f);
    glEnd();

    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(25.0f, -165.0f);
    glVertex2f(17.0f, -165.0f);
    glEnd();

    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(15.0f, -168.0f);
    glVertex2f(10.0f, -168.0f);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(40.0f,20.0f, 0.0f);

    glPushMatrix();
    glTranslatef(-110.0f,-100.0f, 0.0f);
    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(20.0f, -160.0f);
    glVertex2f(15.0f, -160.0f);
    glEnd();

    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(25.0f, -165.0f);
    glVertex2f(17.0f, -165.0f);
    glEnd();

    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(15.0f, -168.0f);
    glVertex2f(10.0f, -168.0f);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(150.0f,-20.0f, 0.0f);

    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(-90.0f, -120.0f);
    glVertex2f(-75.0f, -120.0f);
    glEnd();

    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(-85.0f, -125.0f);
    glVertex2f(-70.0f, -125.0f);
    glEnd();

    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(-93.0f, -130.0f);
    glVertex2f(-82.0f, -130.0f);
    glEnd();
    glPopMatrix();


    glPushMatrix();
    glTranslatef(180.0f,-120.0f, 0.0f);

    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(-90.0f, -120.0f);
    glVertex2f(-75.0f, -120.0f);
    glEnd();

    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(-85.0f, -125.0f);
    glVertex2f(-70.0f, -125.0f);
    glEnd();

    glLineWidth(0.5);
    glBegin(GL_LINES);
    glColor3ub(64,64,64);
    glVertex2f(-93.0f, -130.0f);
    glVertex2f(-82.0f, -130.0f);
    glEnd();
    glPopMatrix();
    glPopMatrix();


    glPopMatrix();
}

//U1
void update1(int value) {

    _move1 += 1.0;
    if(_move1 > 200.0)
    {
        _move1 = -100.0;
    }
    glutPostRedisplay(); //Notify GLUT that the display has changed

    glutTimerFunc(50, update1, 0); //Notify GLUT to call update again in 25 milliseconds
}
void update2(int value) {

    _move2 -= 1.0;
    if(_move2 < -20.0)
    {
        _move2 += 250.0;
    }

    glutPostRedisplay(); //Notify GLUT that the display has changed

    glutTimerFunc(50, update2, 0); //Notify GLUT to call update again in 25 milliseconds
}
void update4(int value) {

    _move4 += 2.0;
    if(_move4 > 250.0)
    {
        _move4 = -100.0;
    }
    glutPostRedisplay(); //Notify GLUT that the display has changed

    glutTimerFunc(50, update4, 0); //Notify GLUT to call update again in 25 milliseconds
}
void update5(int value) {

    _move5 -= 1.0;
    if(_move5 < -200.0)
    {
        _move5 += 250.0;
    }

    glutPostRedisplay(); //Notify GLUT that the display has changed

    glutTimerFunc(60, update5, 0); //Notify GLUT to call update again in 25 milliseconds
}

void Water()//Water W
{
    glColor3ub(56,125,229);
    glBegin(GL_POLYGON);
    glVertex2f(-100.0f,-280.0f);
	glVertex2f(200.0f,-280.0f);
	glVertex2f(200.0f,-100.0f);
	glVertex2f(-100.0f,-100.0f);
	glEnd();
}


void Background()//Background B
{
    glColor3ub(135,206,235);
    glBegin(GL_POLYGON);
    glVertex2f(200.0f,200.0f);
	glVertex2f(-100.0f,200.0f);
	glColor3ub(128,128,128);
    glVertex2f(-100.0f,-100.0f);
	glVertex2f(200.0f,-100.0f);


	glEnd();
}


//Day version
void display() {

	glClear(GL_COLOR_BUFFER_BIT);   // Clear the color buffer with current clearing color

    Background();
    Cloud1();
    Cloud2();
    Cloud3();
    Cloud4();
    Water();
    Wave();
    SpeedBoat();
    Ship1();
    Ship2();

    glPushMatrix();
    glTranslatef(-130.0f, 100.0f, 0.0f);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(-130.0f, 85.0f, 0.0f);

    glPopMatrix();

	glFlush();  // Render now
	glutSwapBuffers();
}


/* Main function: GLUT runs as a console application starting at main()  */
int main(int argc, char** argv) {

	glutInit(&argc, argv);          // Initialize GLUT
	glutInitWindowSize(1300, 670);   // Set the window's initial width & height
	glutCreateWindow("Karnaphuli Skyline");  // Create window with the given title
	glutInitWindowPosition(50, 50); // Position the window's initial top-left corner
	initGL();                       // Our own OpenGL initialization
	glutDisplayFunc(display);
    glutTimerFunc(20,UpdateCloud, 0);
    glutTimerFunc(50,update1, 0);
    glutTimerFunc(50,update2, 0);
    glutTimerFunc(50,update4, 0);
    glutTimerFunc(60,update5, 0);

	glutMainLoop();                 // Enter the event-processing loop

	return 0;

}
